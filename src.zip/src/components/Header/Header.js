import { Link } from 'react-router-dom';
// import { useContext } from 'react';
// import AuthContext from '../../contexts/AuthContext';
// import { useHistory } from 'react-router-dom';


export default function Header() {
    // const { user } = useContext(AuthContext);
    // const historyHook = useHistory();
    // const onButtonClick = () => {
    //     historyHook.push('/login')
    // }
    // let guestNavigation = (
    //     <div id="guest">
    //         <ul className='nav navbar-nav navbar-right scroll'>
    //             <li><Link to='/login' onClick={onButtonClick} >Вход</Link></li>
    //         </ul>
    //         <ul className='nav navbar-nav navbar-right scroll'>
    //             <li className='active'><Link to='#home'>Начало</Link></li>
    //             <li ><Link to='#about'>За мен</Link></li>
    //             <li ><Link to='#works'>Проекти</Link></li>
    //             <li ><Link to='#partners'>Партньори</Link></li>
    //             <li ><Link to='#contact' >Контакти</Link></li>
    //         </ul>
    //     </div>
    // );
    // let userNavigation = (
    //     <div id="user">
    //         <span>Welcome, User</span>
    //         <ul className='nav navbar-nav navbar-right'>
    //             < li ><Link to='/login' >Вход</Link></li>
    //             {/* < li ><Link to='/comments' >Коментари</Link></li> */}
    //             < li ><Link to='/add' >Добави коментар</Link></li>
    //             < li ><Link to='/admin' >Админ панел</Link></li>
    //         </ul>
    //         <ul className='nav navbar-nav navbar-right scroll'>
    //             <li className='active'><Link to='#home'>Начало</Link></li>
    //             <li ><Link to='#about'>За мен</Link></li>
    //             <li ><Link to='#works'>Проекти</Link></li>
    //             <li ><Link to='#partners'>Партньори</Link></li>
    //             <li ><Link to='#contact'>Контакти</Link></li>
    //         </ul>
    //     </div>
    // );
    return (
        <div className='navbar-wrapper'>
            <div className='container'>
                <div className='navbar navbar-inverse navbar-fixed-top' role='navigation' id='top-nav'>
                    <div className='container'>
                        <div className='navbar-header'>
                            <Link to='/'><img src='images/logo-removebg-preview.png' className='logo' alt='logo' /></Link>
                            <button type='button' className='navbar-toggle collapsed' data-toggle='collapse' data-target='.navbar-collapse'>
                                <span className='sr-only'>Toggle navigation</span>
                                <span className='icon-bar'></span>
                                <span className='icon-bar'></span>
                                <span className='icon-bar'></span>
                            </button>
                        </div>
                        <div className='navbar-collapse collapse'>
                            <ul className='nav navbar-nav navbar-right'>
                                < li ><Link to='/login' >Вход</Link></li>
                                {/* < li ><Link to='/comments' >Коментари</Link></li>  */}
                                < li ><Link to='/add' >Добави коментар</Link></li>
                                < li ><Link to='/admin' >Админ панел</Link></li>
                                < li ><Link to='/user' >My space</Link></li>
                            </ul>
                            <ul className='nav navbar-nav navbar-right scroll'>
                                <li className='active'><Link to='#home'>Начало</Link></li>
                                <li ><Link to='#about'>За мен</Link></li>
                                <li ><Link to='#works'>Проекти</Link></li>
                                <li ><Link to='#partners'>Партньори</Link></li>
                                <li ><Link to='#contact'>Контакти</Link></li>
                            </ul>
                            {/* {user.email
                                ? userNavigation
                                : guestNavigation
                            } */}
                        </div>
                    </div>
                </div>
            </div>
        </div >
    );
}