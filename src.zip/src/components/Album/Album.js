import Logo from '../Logo/Logo';
import AlbumCard from './AlbumCard';
// import './album.css';
const Album1 = () => {
    return (
        <div id='album' className='album-container'>
            <Logo />
            <div id='myCarousel' className='carousel slide banner-slider animated bounceInDown' data-ride='carousel'>
                <div div className='carousel-inner card'>
                    <AlbumCard
                        title=''
                        img='/images/slide1.jpg'
                        className='item active cont'
                    />
                    <AlbumCard
                        title=''
                        img='/images/slide2.jpg'
                        className='item cont'
                    />
                    <AlbumCard
                        title=''
                        img='/images/slide3.jpg'
                        className='item cont'
                    />
                    <AlbumCard
                        title=''
                        img='/images/slide4.jpg'
                        className='item cont'
                    />
                    <AlbumCard
                        title=''
                        img='/images/slide5.jpg'
                        className='item cont'
                    />
                </div>
                <a className='left carousel-control' href='#myCarousel' data-slide='prev'><span className='glyphicon-chevron-left'><i className='fa fa-angle-left'></i></span></a>
                <a className='right carousel-control' href='#myCarousel' data-slide='next'><span className='glyphicon-chevron-right'><i className='fa fa-angle-right'></i></span></a>
            </div>
        </div>
    );
}

export default Album1;